import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";

import { PageHeader } from "@/components/page-header";
import { ProjectMedia } from "@/components/project-media";
import { StatusPill } from "@/components/status-pill";
import { money } from "@/lib/money";
import { createClient } from "@/lib/supabase/server";

export default async function ProjectDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: project, error } = await supabase
    .from("projects")
    .select(
      `
      *,
      customers(
        first_name,
        last_name,
        company_name,
        phone,
        email,
        project_address
      ),
      estimates(
        id,
        estimate_number,
        title,
        total,
        project_address,
        scope,
        payment_schedule
      )
    `,
    )
    .eq("id", id)
    .single();

  if (error || !project) {
    notFound();
  }

  const { data: mediaRows } = await supabase
    .from("project_media")
    .select(
      "id,storage_path,file_name,category,room_location,caption,customer_visible,created_at",
    )
    .eq("project_id", id)
    .order("created_at", { ascending: false });

  const media = await Promise.all(
    (mediaRows ?? []).map(async (item) => {
      const { data } = await supabase.storage
        .from("project-media")
        .createSignedUrl(item.storage_path, 60 * 60);

      return {
        ...item,
        signed_url: data?.signedUrl ?? null,
      };
    }),
  );

  const customer = project.customers as any;
  const estimate = project.estimates as any;

  const projectTitle = estimate?.title || project.name || "Project";
  const address =
    estimate?.project_address ||
    customer?.project_address ||
    project.project_address ||
    null;

  return (
    <div className="page-wrap">
      <div className="project-detail-back">
        <Link href="/projects">
          <ArrowLeft size={16} />
          Back to projects
        </Link>
      </div>

      <PageHeader
        eyebrow={estimate?.estimate_number || "Project"}
        title={projectTitle}
        description={
          customer
            ? `${customer.first_name} ${customer.last_name}${
                address ? ` • ${address}` : ""
              }`
            : address || "Accepted Ironwood project"
        }
      />

      <section className="project-overview-grid">
        <article className="panel">
          <span className="project-overview-label">Status</span>
          <div className="project-overview-value">
            <StatusPill value={project.status} />
          </div>
        </article>

        <article className="panel">
          <span className="project-overview-label">Contract</span>
          <strong className="project-overview-number">
            {money(project.contract_total ?? estimate?.total ?? 0)}
          </strong>
        </article>

        <article className="panel">
          <span className="project-overview-label">Paid</span>
          <strong className="project-overview-number">
            {money(project.amount_paid ?? 0)}
          </strong>
        </article>

        <article className="panel">
          <span className="project-overview-label">Remaining</span>
          <strong className="project-overview-number">
            {money(
              Math.max(
                0,
                Number(project.contract_total ?? estimate?.total ?? 0) -
                  Number(project.amount_paid ?? 0),
              ),
            )}
          </strong>
        </article>
      </section>

      {(estimate?.scope || estimate?.payment_schedule) && (
        <section className="panel project-detail-info">
          {estimate?.scope && (
            <div>
              <h2>Scope</h2>
              <p className="pre-line">{estimate.scope}</p>
            </div>
          )}

          {estimate?.payment_schedule && (
            <div>
              <h2>Payment schedule</h2>
              <p className="pre-line">{estimate.payment_schedule}</p>
            </div>
          )}
        </section>
      )}

      <ProjectMedia
        projectId={project.id}
        estimateId={estimate?.id ?? null}
        initialMedia={media}
      />
    </div>
  );
}
